# hw-extensions

## 1、下载

[Release](https://github.com/godwei123/hw-extensions/releases/download/beta/extensions.v0.0.1-beta.zip)  或 源码中 [extensions.zip](https://github.com/godwei123/hw-extensions/blob/main/extensions.zip) 压缩包



## 2、安装

1、打开Google浏览器/Edge浏览器

2、打开管理扩展程序

![image-20221112215213313](doc/image-20221112215213313.png)



3、打开开发者模式

![image-20221112215257516](doc/image-20221112215257516.png)



4、加载解压后的文件

![image-20221112215314316](doc/image-20221112215314316.png)







## 3、使用

1、登录后点击申请进展
![在这里插入图片描述](doc/5764640b65474749afc817ea3b14798a.png)
2、进入页面后即弹出状态码

![在这里插入图片描述](doc/e8c8ee51b796455cbb4029d96bfe592a.png)
