chrome.runtime.onInstalled.addListener(() => {
    console.log('chrome.runtime.onInstalled');
});

